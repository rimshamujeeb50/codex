import sqlite3
"Nursery.db"
conn = sqlite3.connect("Nursery.db")
def orders_view():
    record=conn.execute("select * from orders")
    for i in record:
        print(i)
