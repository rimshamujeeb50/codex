import sqlite3
"Nursery.db"
conn = sqlite3.connect("Nursery.db")
def complaints_view():
    records=conn.execute("select * from complaint")
    for i in records:
        print(i)