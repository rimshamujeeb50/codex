import sqlite3
"nursery.db"
conn = sqlite3.connect("nursery.db")

query1 = ''' create table plants(id int primary key,name text not null  DEFAULT Rose,pieces int not null,price int not null)'''
conn.execute(query1)

query2 = ''' create table orders(o_id int primary key,o_name text not null,total_price int not null)'''
conn.execute(query2)

query3 = ''' create table complaint(order_id int primary key,customer_name text not null ,complaint text not null)'''
conn.execute(query3)

conn.commit()
