import sqlite3
"nursery.db"
conn = sqlite3.connect("nursery.db")
cursor=conn.cursor()


class plant_not_present(Exception):
   def show(self):
       print("plant kind not available in database")
class emptyy(Exception):
    def display(self):
        print("PLANTS TABLE IS EMPTY.")

def plant_del(n):
        try:
          x=conn.execute('''
                      select count(*) from plants
          ''')
          for i in x:
              w=i[0]
          if(w==0):
             raise emptyy()
          else :
              try:
                  cursor.execute("Select name from plants WHERE name=?",(n,))
                  exists=cursor.fetchall()
                  if exists:
                      conn.execute(" delete from plants where name= '" + n + "' ")
                      print("Your plant has been deleted successfully!")
                      conn.commit()
                  else:
                      raise plant_not_present
              except plant_not_present as pnp:
                  pnp.show()
        except emptyy as e:
           e.display()




