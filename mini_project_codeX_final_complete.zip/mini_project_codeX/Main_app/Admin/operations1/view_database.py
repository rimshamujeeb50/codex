import sqlite3
"nursery.db"
conn = sqlite3.connect("nursery.db")

def view_database():  #--here show only plants table
    queryy='''select * from plants'''
    d=conn.execute(queryy)
    for i in d:
        print(i)
    conn.commit()