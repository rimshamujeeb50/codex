import sqlite3
"nursery.db"
conn = sqlite3.connect("nursery.db")

def complaints():
    order_id = int(input("enter order number:"))
    customer_name = input("enter your name:")
    complaint=input("enter the complaint: ")
    data={}
    data['order_id']=order_id
    data['customer_name']=customer_name
    data['complaint']=complaint
    conn.execute('''
             insert into complaint(order_id,customer_name,complaint) values(?,?,?)
    ''',(data.get("order_id"),data.get("customer_name"),data.get("complaint")))
    conn.commit()
    print("data inserted successfully!!!")
    return data