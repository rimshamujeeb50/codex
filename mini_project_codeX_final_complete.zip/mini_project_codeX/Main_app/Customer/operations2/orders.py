
import sqlite3
"nursery.db"
conn = sqlite3.connect("nursery.db")

def your_orders():

         bill=0
         n=int(input("enter no.of plants variety  u want to purchase:"))
         s=""
         for i in range(0,n):
            id = int(input("enter plant id  :"))
            name = input("enter plant name:")
            pieces = int(input("enter no. of plant pieces: "))
            s+=name
            x1 = conn.execute('''SELECT count(*) FROM orders''')
            for i in x1:
                ex=i[0]
            s+=","
            r = conn.execute("select price from plants where id='" + str(id) + "'")
            for i in r:
                l=i
            t=int(l[0])
            bill=bill+(t*pieces)
         if ex ==0:
             o_no=1
         else:
             x = conn.execute('''select o_id from orders Order by o_id DESC LIMIT 1''')
             for i in x:
                 o_no=i[0]+1


         conn.execute('''
                         insert into orders(o_id,o_name,total_price) values(?,?,?)
               ''', (o_no,s,str(bill)))
         conn.commit()
         print("data inserted successfully!!!")






