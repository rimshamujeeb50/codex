from Main_app.Admin import admin_portal as ap
from Main_app.Customer import customer_portal as cp
while(True):
    print('''
    WELCOME TO codeX NURSERY.
    1.Admin Portal
    2.Customer Portal
    3.Exit''')
    print("choose your Role :")
    ch=int(input())
    if ch == 1:
        ap.admin_portal()
    elif ch == 2:
        cp.customer_portal()

    else :
        break