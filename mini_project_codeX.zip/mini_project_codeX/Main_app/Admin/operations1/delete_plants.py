def delete_plants():
    print("hello")