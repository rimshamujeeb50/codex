def orders_view():
    print("hello")
