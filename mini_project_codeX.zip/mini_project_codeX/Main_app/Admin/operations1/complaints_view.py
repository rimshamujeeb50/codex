def complaints_view():
    print("hello")