def view_database():  #--here show only plants table
    print("hello")