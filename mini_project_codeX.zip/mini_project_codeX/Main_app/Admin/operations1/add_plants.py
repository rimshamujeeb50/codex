def add_plants():
    print("hello")