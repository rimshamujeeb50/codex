def order_plants():
    print("i am order plants")